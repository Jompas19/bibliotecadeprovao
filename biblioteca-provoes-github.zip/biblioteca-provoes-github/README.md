# Biblioteca de Provões

Site estático de questões interativas, preparado para GitHub Pages.

## Publicação

1. Crie um repositório no GitHub.
2. Envie `index.html` para a raiz do repositório.
3. Em **Settings > Pages**, selecione a publicação a partir da branch principal (`main`) e da pasta raiz (`/root`).
4. Mantenha o mesmo repositório/endereço nas atualizações futuras.

## Dados dos usuários

O progresso, categorias, gabaritos personalizados, tema e anotações são armazenados localmente no navegador de cada usuário, usando IndexedDB (com fallback para localStorage).

Atualizar o `index.html` não apaga esses dados, desde que permaneçam estáveis:

- o domínio/endereço de publicação;
- o nome do banco `QuestoesInterativasDB`;
- o prefixo `QuestoesInterativasDB:`;
- os IDs internos das questões já existentes.

Ao corrigir uma questão, preserve o seu `id`. Ao adicionar uma questão nova, use um novo `id` que nunca tenha sido usado anteriormente.

## Troca de computador/navegador

Os dados locais não sincronizam entre dispositivos. Use os botões **Backup** e **Restaurar** do próprio site para transferir o progresso.

## Primeira migração do arquivo local para o site online

O armazenamento de uma página aberta via `file://` é diferente do armazenamento do GitHub Pages. Para levar o progresso atual ao site online:

1. Abra a versão local antiga.
2. Clique em **Backup**.
3. Abra o endereço publicado no GitHub Pages.
4. Clique em **Restaurar** e selecione o backup.
